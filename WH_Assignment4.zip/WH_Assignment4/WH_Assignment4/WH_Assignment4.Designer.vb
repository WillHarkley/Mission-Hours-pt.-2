﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWH_Assignment4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblhrsdonated = New System.Windows.Forms.Label()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.lblmissionhrs = New System.Windows.Forms.Label()
        Me.lstMissions = New System.Windows.Forms.ListBox()
        Me.btnAddhrs = New System.Windows.Forms.Button()
        Me.lstTotals = New System.Windows.Forms.ListBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblCooking = New System.Windows.Forms.Label()
        Me.lblCookingdisplay = New System.Windows.Forms.Label()
        Me.lblItemInventory = New System.Windows.Forms.Label()
        Me.lblItemDisplay = New System.Windows.Forms.Label()
        Me.lblConstruction = New System.Windows.Forms.Label()
        Me.lblConstructionDisplay = New System.Windows.Forms.Label()
        Me.lblCleaning = New System.Windows.Forms.Label()
        Me.lblCleaningDisplay = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblhrsdonated
        '
        Me.lblhrsdonated.AutoSize = True
        Me.lblhrsdonated.Font = New System.Drawing.Font("Poor Richard", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhrsdonated.Location = New System.Drawing.Point(122, 99)
        Me.lblhrsdonated.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblhrsdonated.Name = "lblhrsdonated"
        Me.lblhrsdonated.Size = New System.Drawing.Size(101, 19)
        Me.lblhrsdonated.TabIndex = 0
        Me.lblhrsdonated.Text = "Hours Donated"
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(126, 121)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(100, 23)
        Me.txtAmount.TabIndex = 0
        '
        'lblmissionhrs
        '
        Me.lblmissionhrs.AutoSize = True
        Me.lblmissionhrs.Font = New System.Drawing.Font("Rockwell", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmissionhrs.Location = New System.Drawing.Point(370, 20)
        Me.lblmissionhrs.Name = "lblmissionhrs"
        Me.lblmissionhrs.Size = New System.Drawing.Size(147, 23)
        Me.lblmissionhrs.TabIndex = 2
        Me.lblmissionhrs.Text = "Mission Hours"
        '
        'lstMissions
        '
        Me.lstMissions.FormattingEnabled = True
        Me.lstMissions.ItemHeight = 16
        Me.lstMissions.Location = New System.Drawing.Point(69, 157)
        Me.lstMissions.Name = "lstMissions"
        Me.lstMissions.Size = New System.Drawing.Size(239, 228)
        Me.lstMissions.TabIndex = 1
        '
        'btnAddhrs
        '
        Me.btnAddhrs.Location = New System.Drawing.Point(126, 391)
        Me.btnAddhrs.Name = "btnAddhrs"
        Me.btnAddhrs.Size = New System.Drawing.Size(112, 36)
        Me.btnAddhrs.TabIndex = 2
        Me.btnAddhrs.Text = "&Add Hours"
        Me.btnAddhrs.UseVisualStyleBackColor = True
        '
        'lstTotals
        '
        Me.lstTotals.FormattingEnabled = True
        Me.lstTotals.ItemHeight = 16
        Me.lstTotals.Location = New System.Drawing.Point(416, 74)
        Me.lstTotals.Name = "lstTotals"
        Me.lstTotals.Size = New System.Drawing.Size(275, 308)
        Me.lstTotals.TabIndex = 5
        Me.lstTotals.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(498, 391)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(91, 36)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "Clos&e"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lblCooking
        '
        Me.lblCooking.AutoSize = True
        Me.lblCooking.Location = New System.Drawing.Point(781, 74)
        Me.lblCooking.Name = "lblCooking"
        Me.lblCooking.Size = New System.Drawing.Size(57, 16)
        Me.lblCooking.TabIndex = 7
        Me.lblCooking.Text = "Cooking"
        '
        'lblCookingdisplay
        '
        Me.lblCookingdisplay.AutoSize = True
        Me.lblCookingdisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCookingdisplay.Location = New System.Drawing.Point(762, 90)
        Me.lblCookingdisplay.MinimumSize = New System.Drawing.Size(100, 50)
        Me.lblCookingdisplay.Name = "lblCookingdisplay"
        Me.lblCookingdisplay.Size = New System.Drawing.Size(100, 50)
        Me.lblCookingdisplay.TabIndex = 8
        '
        'lblItemInventory
        '
        Me.lblItemInventory.AutoSize = True
        Me.lblItemInventory.Location = New System.Drawing.Point(770, 157)
        Me.lblItemInventory.Name = "lblItemInventory"
        Me.lblItemInventory.Size = New System.Drawing.Size(92, 16)
        Me.lblItemInventory.TabIndex = 9
        Me.lblItemInventory.Text = "Item Inventory"
        '
        'lblItemDisplay
        '
        Me.lblItemDisplay.AutoSize = True
        Me.lblItemDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblItemDisplay.Location = New System.Drawing.Point(762, 173)
        Me.lblItemDisplay.MinimumSize = New System.Drawing.Size(100, 50)
        Me.lblItemDisplay.Name = "lblItemDisplay"
        Me.lblItemDisplay.Size = New System.Drawing.Size(100, 50)
        Me.lblItemDisplay.TabIndex = 10
        '
        'lblConstruction
        '
        Me.lblConstruction.AutoSize = True
        Me.lblConstruction.Location = New System.Drawing.Point(770, 236)
        Me.lblConstruction.Name = "lblConstruction"
        Me.lblConstruction.Size = New System.Drawing.Size(82, 16)
        Me.lblConstruction.TabIndex = 11
        Me.lblConstruction.Text = "Construction"
        '
        'lblConstructionDisplay
        '
        Me.lblConstructionDisplay.AutoSize = True
        Me.lblConstructionDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblConstructionDisplay.Location = New System.Drawing.Point(762, 252)
        Me.lblConstructionDisplay.MinimumSize = New System.Drawing.Size(100, 50)
        Me.lblConstructionDisplay.Name = "lblConstructionDisplay"
        Me.lblConstructionDisplay.Size = New System.Drawing.Size(100, 50)
        Me.lblConstructionDisplay.TabIndex = 12
        '
        'lblCleaning
        '
        Me.lblCleaning.AutoSize = True
        Me.lblCleaning.Location = New System.Drawing.Point(781, 315)
        Me.lblCleaning.Name = "lblCleaning"
        Me.lblCleaning.Size = New System.Drawing.Size(60, 16)
        Me.lblCleaning.TabIndex = 13
        Me.lblCleaning.Text = "Cleaning"
        '
        'lblCleaningDisplay
        '
        Me.lblCleaningDisplay.AutoSize = True
        Me.lblCleaningDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCleaningDisplay.Location = New System.Drawing.Point(762, 332)
        Me.lblCleaningDisplay.MinimumSize = New System.Drawing.Size(100, 50)
        Me.lblCleaningDisplay.Name = "lblCleaningDisplay"
        Me.lblCleaningDisplay.Size = New System.Drawing.Size(100, 50)
        Me.lblCleaningDisplay.TabIndex = 14
        '
        'frmWH_Assignment4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.ClientSize = New System.Drawing.Size(918, 458)
        Me.Controls.Add(Me.lblCleaningDisplay)
        Me.Controls.Add(Me.lblCleaning)
        Me.Controls.Add(Me.lblConstructionDisplay)
        Me.Controls.Add(Me.lblConstruction)
        Me.Controls.Add(Me.lblItemDisplay)
        Me.Controls.Add(Me.lblItemInventory)
        Me.Controls.Add(Me.lblCookingdisplay)
        Me.Controls.Add(Me.lblCooking)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lstTotals)
        Me.Controls.Add(Me.btnAddhrs)
        Me.Controls.Add(Me.lstMissions)
        Me.Controls.Add(Me.lblmissionhrs)
        Me.Controls.Add(Me.txtAmount)
        Me.Controls.Add(Me.lblhrsdonated)
        Me.Font = New System.Drawing.Font("Rockwell", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmWH_Assignment4"
        Me.Text = "Assignment 4"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblhrsdonated As Label
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents lblmissionhrs As Label
    Friend WithEvents lstMissions As ListBox
    Friend WithEvents btnAddhrs As Button
    Friend WithEvents lstTotals As ListBox
    Friend WithEvents btnClose As Button
    Friend WithEvents lblCooking As Label
    Friend WithEvents lblCookingdisplay As Label
    Friend WithEvents lblItemInventory As Label
    Friend WithEvents lblItemDisplay As Label
    Friend WithEvents lblConstruction As Label
    Friend WithEvents lblConstructionDisplay As Label
    Friend WithEvents lblCleaning As Label
    Friend WithEvents lblCleaningDisplay As Label
End Class
