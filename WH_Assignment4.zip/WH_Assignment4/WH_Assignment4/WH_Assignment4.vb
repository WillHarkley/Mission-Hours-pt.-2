﻿Public Class frmWH_Assignment4
    'Name: WH_Assignment 4
    'Purpose: To record completed mission hours with the name of participants
    'Programmer: William Harkley

    Dim missions() As String = {"Cooking", "Item Inventory", "Construction", "Cleaning"}

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnAddhrs_Click(sender As Object, e As EventArgs) Handles btnAddhrs.Click
        'Defined variables
        Dim inthours As Integer
        Dim strmissions As String

        'This is to hold the number of hours entered
        Static inttotals(4) As Integer

        strmissions = lstMissions.SelectedItem

        Integer.TryParse(txtAmount.Text, inthours)

        Dim inttotalindex As Integer = lstMissions.SelectedIndex
        inttotals(inttotalindex) = inttotals(inttotalindex) + inthours


        lblCookingdisplay.Text = inttotals(0).ToString
        lblItemDisplay.Text = inttotals(1).ToString
        lblConstructionDisplay.Text = inttotals(2).ToString
        lblCleaningDisplay.Text = inttotals(3).ToString


        Dim strname As String = InputBox("Please enter name of volunteer")
        If strname = "" Then
            MessageBox.Show("Please enter volunteer name")
            Return
        End If

        If txtAmount.Text = "" Then
            MessageBox.Show("Please enter number of hours completed")
        End If
        lstTotals.Items.Add(getName(strname) & " completed " & inthours & " hours")
        txtAmount.Text = ""
        lstMissions.SelectedIndex = -1

    End Sub

    Function getName(ByVal newname As String) As String


        Dim index As Integer
        Dim lastname, firstname As String

        index = newname.IndexOf(" ")
        firstname = newname.Substring(0, index)
        lastname = newname.Substring(index + 1)

        Return lastname
    End Function

    Private Sub frmWH_Assignment4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i As Integer = 0 To missions.Count - 1
            lstMissions.Items.Add(missions(i))
        Next
    End Sub

    Private Sub lstTotals_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstTotals.SelectedIndexChanged
        'lstTotals.Text = Date.Now.ToString("ddd dd-MM-yyyy")

        lstTotals.Items.Add("Hours recorded for " & Date.Now.ToString("dd/MM/yyyy"))
    End Sub
End Class